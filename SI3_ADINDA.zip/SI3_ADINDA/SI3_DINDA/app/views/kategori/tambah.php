<h2>Tambah Kategori</h2>

<form action="Proses" method="post">
    <table>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="kat_nama"></td>
        </tr>
        <tr>
            <td>KETERANGAN</td>
            <td><textarea name="kat_keterangan" id="" cols="30" rows="10"></textarea></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>