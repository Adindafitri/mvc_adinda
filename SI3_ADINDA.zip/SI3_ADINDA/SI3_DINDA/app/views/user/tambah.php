<h2>Tambah User</h2>

<form action="Proses" method="post">
    <table>
        <tr>
            <td>EMAIL</td>
            <td><input type="text" name="user_email"></td>
        </tr>
        <tr>
            <td>PASSWORD</td>
            <td><input name="user_password" type="text"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input name="user_nama" type="text"></td>
        </tr>
        <tr>
            <td>ALAMAT</td>
            <td><input name="user_alamat" type="text"></td>
        </tr>
        <tr>
            <td>HP</td>
            <td><input name="user_hp" type="text"></td>
        </tr>
        <tr>
            <td>POS</td>
            <td><input name="user_pos" type="text"></td>
        </tr>
        <tr>
            <td>ROLE</td>
            <td><input name="user_role" type="text"></td>
        </tr>
        <tr>
            <td>AKTIF</td>
            <td><input name="user_aktif" type="text"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>